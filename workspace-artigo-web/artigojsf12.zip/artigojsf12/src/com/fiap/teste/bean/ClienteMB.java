package com.fiap.teste.bean;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ClienteMB {

	public ClienteMB() {
		cliente = new Cliente();
	}

	private Cliente cliente;
	private List<Cliente> clienteList = new ArrayList<Cliente>();

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public List<Cliente> getClienteList() {
		return clienteList;
	}

	public void setClienteList(List<Cliente> clienteList) {
		this.clienteList = clienteList;
	}

	public String inserirCliente() {
		cliente.setIdCliente(new Random().nextInt());
		clienteList.add(cliente);
		cliente = new Cliente();
		return "success";
	}

	public String removerCliente() {
		clienteList.remove(cliente);
		cliente = new Cliente();
		return "success";
	}
}
